package com.javasampleapproach.wardeployment.controller;

import java.sql.SQLException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import java.sql.*;
import oracle.jdbc.pool.*;
import oracle.jdbc.pool.OracleDataSource;
import java.util.List;
import java.util.ArrayList;

@Controller
public class WebController {
	@RequestMapping(value={"/"})
    public String home(){
        Connection conn = null;
        ResultSet rset = null;
		Statement stmt = null;
		OracleDataSource ODS = null;
		//List<Channels> resultList = new ArrayList<>();
		try {
			ODS = new OracleDataSource();
			System.out.println("DS created");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ODS.setURL("jdbc:oracle:thin:@"+"demoadwc_high"+"?TNS_ADMIN="+"/Users/megha/instantclient_12_2/network/admin/");
		ODS.setUser("admin");
		ODS.setPassword("DemoADWC12345678");

		try {
			conn = ODS.getConnection();
			System.out.println("inside ODS.get connection");

			//PreparedStatement stmt = conn.prepareStatement("select CHANNEL_DESC from channels");
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			System.out.println("after prepared statement");

			//rset = stmt.executeQuery("select CHANNEL_DESC from channels_demo");

			rset = stmt.executeQuery("select CHANNEL_DESC from channels_demo");
			System.out.println("after execute statement");

            //System.out.println(rset.getString("CHANNEL_DESC"));

            while (rset.next()){
            System.out.println(rset.getString("CHANNEL_DESC"));
			}

            /*
			while (rset.next()){
            resultList.add(
                new Channels(rset.getString("CHANNEL_DESC"))
                );
			}
			System.out.println(resultList);

			rset.afterLast();
            while (rset.previous())
            {
                System.out.println(rset.getString("CHANNEL_DESC"));
            }*/

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Connection test Succeeded. You are connected to ATP as Admin!");
        return "home";
    }
}